// Matcha Energy Meter - p5.js Version
// Timer durations (in seconds)
const WORK_DURATION = 60 * 60; // 1 hour
const BREAK_LIMIT = 5 * 60;    // 5 minutes

// For testing, use these shorter durations:
// const WORK_DURATION = 60;    // 1 minute
// const BREAK_LIMIT = 10;      // 10 seconds

// State variables
let state = 'idle'; // idle, working, break, overtime
let workTimeElapsed = 0;
let breakTimeElapsed = 0;
let sessionsCompleted = 0;
let cupFillPercent = 0;

// Button objects
let startBtn, breakBtn, resetBtn;

// Sparkle animation
let showSparkles = false;
let sparkleTimer = 0;

function setup() {
  createCanvas(600, 800);
  
  // Create buttons
  startBtn = createButton('Start Focus');
  startBtn.position(width/2 - 180, 600);
  startBtn.size(150, 50);
  startBtn.mousePressed(startWork);
  startBtn.style('font-size', '16px');
  startBtn.style('background', '#6b8e23');
  startBtn.style('color', 'white');
  startBtn.style('border', 'none');
  startBtn.style('border-radius', '25px');
  startBtn.style('cursor', 'pointer');
  startBtn.style('font-weight', 'bold');
  
  breakBtn = createButton('Take Break');
  breakBtn.position(width/2 - 15, 600);
  breakBtn.size(150, 50);
  breakBtn.mousePressed(startBreak);
  breakBtn.style('font-size', '16px');
  breakBtn.style('background', '#4a90e2');
  breakBtn.style('color', 'white');
  breakBtn.style('border', 'none');
  breakBtn.style('border-radius', '25px');
  breakBtn.style('cursor', 'pointer');
  breakBtn.style('font-weight', 'bold');
  breakBtn.attribute('disabled', '');
  breakBtn.style('opacity', '0.5');
  
  resetBtn = createButton('Reset');
  resetBtn.position(width/2 + 150, 600);
  resetBtn.size(150, 50);
  resetBtn.mousePressed(reset);
  resetBtn.style('font-size', '16px');
  resetBtn.style('background', '#e74c3c');
  resetBtn.style('color', 'white');
  resetBtn.style('border', 'none');
  resetBtn.style('border-radius', '25px');
  resetBtn.style('cursor', 'pointer');
  resetBtn.style('font-weight', 'bold');
  
  textAlign(CENTER, CENTER);
}

function draw() {
  // Gradient background
  setGradient(0, 0, width, height, color(245, 247, 250), color(195, 207, 226));
  
  // Title
  fill(45, 74, 43);
  textSize(48);
  textStyle(BOLD);
  text('🍵 Matcha Energy Meter', width/2, 60);
  
  // Draw cup
  drawCup();
  
  // Draw sparkles if active
  if (showSparkles) {
    drawSparkles();
    sparkleTimer++;
    if (sparkleTimer > 180) { // 3 seconds at 60fps
      showSparkles = false;
      sparkleTimer = 0;
    }
  }
  
  // Status text
  fill(45, 74, 43);
  textSize(24);
  textStyle(BOLD);
  let statusText = getStatusText();
  text(statusText, width/2, 470);
  
  // Timer display
  fill(26, 26, 26);
  textSize(72);
  textStyle(BOLD);
  text(getTimeDisplay(), width/2, 520);
  
  // Progress percentage
  fill(102, 102, 102);
  textSize(22);
  textStyle(NORMAL);
  text(round(cupFillPercent) + '%', width/2, 560);
  
  // Sessions completed
  fill(60, 60, 60);
  textSize(20);
  text('Sessions Completed: ' + sessionsCompleted, width/2, 700);
  
  // Update timers
  if (state === 'working') {
    updateWorkTimer();
  } else if (state === 'break' || state === 'overtime') {
    updateBreakTimer();
  }
}

function drawCup() {
  push();
  translate(width/2, 300);
  
  // Cup body
  fill(255, 255, 255, 240);
  stroke(139, 111, 71);
  strokeWeight(5);
  
  // Cup shape (trapezoid for perspective)
  beginShape();
  vertex(-80, -120);
  vertex(80, -120);
  vertex(100, 120);
  vertex(-100, 120);
  endShape(CLOSE);
  
  // Matcha fill
  let fillHeight = map(cupFillPercent, 0, 100, 0, 240);
  noStroke();
  
  // Matcha gradient
  for (let i = 0; i < fillHeight; i++) {
    let inter = map(i, 0, fillHeight, 0, 1);
    let c = lerpColor(color(90, 122, 61), color(168, 217, 110), inter);
    fill(c);
    let y = 120 - i;
    let topWidth = map(y, -120, 120, 80, 100);
    rect(-topWidth, y, topWidth * 2, 1);
  }
  
  // Cup rim
  fill(139, 111, 71);
  noStroke();
  ellipse(0, -120, 170, 30);
  
  // Foam effect on top of matcha
  if (cupFillPercent > 0) {
    fill(255, 255, 255, 60);
    let foamY = 120 - fillHeight;
    let foamWidth = map(foamY, -120, 120, 80, 100);
    ellipse(0, foamY, foamWidth * 2, 15);
  }
  
  pop();
}

function drawSparkles() {
  push();
  translate(width/2, 180);
  
  let sparkleScale = sin(sparkleTimer * 0.1) * 0.3 + 1;
  scale(sparkleScale);
  
  textSize(60);
  text('✨', -60, 0);
  text('🎉', 0, 0);
  text('✨', 60, 0);
  
  pop();
}

function setGradient(x, y, w, h, c1, c2) {
  noFill();
  for (let i = y; i <= y + h; i++) {
    let inter = map(i, y, y + h, 0, 1);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(x, i, x + w, i);
  }
}

function startWork() {
  if (state === 'working') return;
  
  state = 'working';
  startBtn.attribute('disabled', '');
  startBtn.style('opacity', '0.5');
  breakBtn.removeAttribute('disabled');
  breakBtn.style('opacity', '1');
}

function startBreak() {
  if (state === 'break' || state === 'overtime') return;
  
  state = 'break';
  breakTimeElapsed = 0;
  breakBtn.attribute('disabled', '');
  breakBtn.style('opacity', '0.5');
  startBtn.removeAttribute('disabled');
  startBtn.style('opacity', '1');
}

function reset() {
  state = 'idle';
  workTimeElapsed = 0;
  breakTimeElapsed = 0;
  cupFillPercent = 0;
  showSparkles = false;
  sparkleTimer = 0;
  
  startBtn.removeAttribute('disabled');
  startBtn.style('opacity', '1');
  breakBtn.attribute('disabled', '');
  breakBtn.style('opacity', '0.5');
}

function updateWorkTimer() {
  if (frameCount % 60 === 0) { // Update every second (assuming 60fps)
    workTimeElapsed++;
    cupFillPercent = (workTimeElapsed / WORK_DURATION) * 100;
    
    if (workTimeElapsed >= WORK_DURATION) {
      completeSession();
    }
  }
}

function updateBreakTimer() {
  if (frameCount % 60 === 0) { // Update every second
    breakTimeElapsed++;
    
    if (breakTimeElapsed > BREAK_LIMIT) {
      state = 'overtime';
      // Drain matcha (0.5% per second)
      cupFillPercent = max(0, cupFillPercent - 0.5);
    }
  }
}

function completeSession() {
  state = 'idle';
  sessionsCompleted++;
  cupFillPercent = 100;
  showSparkles = true;
  sparkleTimer = 0;
  
  startBtn.removeAttribute('disabled');
  startBtn.style('opacity', '1');
  breakBtn.attribute('disabled', '');
  breakBtn.style('opacity', '0.5');
}

function getStatusText() {
  switch(state) {
    case 'idle':
      return workTimeElapsed > 0 ? '🎊 Session Complete! Great work!' : 'Ready to focus!';
    case 'working':
      return 'Focus Mode 🎯';
    case 'break':
      return 'Break Time ☕';
    case 'overtime':
      return '⚠️ Break overtime! Matcha draining...';
    default:
      return 'Ready to focus!';
  }
}

function getTimeDisplay() {
  let seconds;
  
  if (state === 'working') {
    seconds = WORK_DURATION - workTimeElapsed;
  } else if (state === 'break') {
    seconds = max(0, BREAK_LIMIT - breakTimeElapsed);
  } else if (state === 'overtime') {
    let overtime = breakTimeElapsed - BREAK_LIMIT;
    return '-' + formatTime(overtime);
  } else {
    return '00:00';
  }
  
  return formatTime(seconds);
}

function formatTime(seconds) {
  let mins = floor(seconds / 60);
  let secs = seconds % 60;
  return nf(mins, 2) + ':' + nf(secs, 2);
}
